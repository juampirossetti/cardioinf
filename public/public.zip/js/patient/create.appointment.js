$(document).ready(function() {
    
    $(".select2").select2();

    $('.control-down').click(function () {
        $(this).siblings('ul').animate({
            scrollTop: '+=100'
        }, 100);
    });

    $('.control-up').click(function () {
        $(this).siblings('ul').animate({
            scrollTop: '-=100'
        }, 100);
    });

    $('.insurance-select').on('change',function(){
        /* Get the selected values */
        var name = $(this).find(":selected").text();
        var id = $(this).find(":selected").val();
        
        /* Set the name and the id in the correct fields */
        $('#insurance-text').text(name);
        $('input[name=insurance_id]').val(id);
    });

    $('.hour-list a').on('click',function(){
        // Remove other active element
        $('.hour-list a').removeClass('active');
        
        //add active class to this element
        $(this).addClass('active')

        //change time value in confirmation section
        var time = $(this).text();
        var date = $(this).closest('div').find('.title').text();
        $('#date-text').text(date+' '+time);
       
        //set date and time in the form
        var date_value = $(this).closest('div').find('.date-value').val();
        $('input[name=date]').val(date_value);
        $('input[name=time]').val(time);
    });
});