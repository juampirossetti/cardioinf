$(document).ready(function() {

    /**************************************************************************
     * Getters
     **************************************************************************/
    var getProfessionalIdSelected = function() {
        
        return $('#professional_id option:selected').val();
    }

    $('#newAppointment').on('click', function(){
        $('#newAppointmentModal').modal('show');
    });
});