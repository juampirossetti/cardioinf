$(document).ready(function() {

    /**************************************************************************
     * Getters
     **************************************************************************/
    var getProfessionalIdSelected = function() {
        
        return $('#professional option:selected').val();
    }

    var getProfessionalNameSelected = function() {
        return $('#professional option:selected').text();
    }
    var getDateSelected = function() {
        
        return $('#calendar').fullCalendar('getDate').format('YYYY-MM-DD');
    }

    var getNumberOfAppointments = function() {
        
        $number = $('.fc-list-item-title :not(:contains("Libre"))').length;        
        return $number;

    }

    var getStartWeekDateSelected = function() {
        return $('#calendar').fullCalendar('getView').intervalStart.format('YYYY-MM-DD');
    }   

    var getEndWeekDateSelected = function() {
        return $('#calendar').fullCalendar('getView').intervalEnd.format('YYYY-MM-DD');
    }

    /**************************************************************************
     * Full Calendar Sources
     **************************************************************************/
    var fcSources = {
        availables: {
            url: '/api/calendar/appointments',
            type: 'POST',
            data: function() {
                    return {
                        status: '0', //Libre
                        professional_id: getProfessionalIdSelected()
                    };
            },
            error: function() {
                alert('Ocurrió un error al cargar los turnos. Por favor intentelo más tarde.');
            },
            color: '#DFF0D8',   // a non-ajax option
            textColor: '#444444' // a non-ajax option
        },
        taken: {
            url: '/api/calendar/appointments',
            type: 'POST',
            data: function() {
                    return {
                        status: '1', //Ocupado
                        professional_id: getProfessionalIdSelected()
                    }
            },
            error: function() {
                alert('Ocurrió un error al cargar los turnos. Por favor intentelo más tarde.');
            },
            color: '#D7F0F7',   // a non-ajax option
            textColor: '#444444' // a non-ajax option
        },
        waiting: {
            url: '/api/calendar/appointments',
            type: 'POST',
            data: function() {
                    return {
                        status: '2', //En Espera
                        professional_id: getProfessionalIdSelected()
                    }
            },
            error: function() {
                alert('Ocurrió un error al cargar los turnos. Por favor intentelo más tarde.');
            },
            color: '#FFB878', // naranja
            textColor: '#444444' // a non-ajax option
        },
        ended: {
            url: '/api/calendar/appointments',
            type: 'POST',
            data: function() {
                    return {
                        status: '3', //Finalizado
                        professional_id: getProfessionalIdSelected()
                    }
            },
            error: function() {
                alert('Ocurrió un error al cargar los turnos. Por favor intentelo más tarde.');
            },
            color: '#E1E1E1',   // a non-ajax option
            textColor: '#444444' // a non-ajax option
        }

    };

    /**************************************************************************
     * Full Calendar
     **************************************************************************/
    // @CARDIOINFANTIL
    var updateButtons = function(){
        var day_name = $('#calendar').fullCalendar('getDate');
        if(getProfessionalIdSelected() == 1 || getProfessionalIdSelected() == 3) {
            if(day_name.format('dddd') == 'viernes') {
                $('.fc-enable_all-button').hide();
                $('.fc-enable_one-button').hide();
            } else {
                $('.fc-enable_all-button').show();
                $('.fc-enable_one-button').show();
            }
        } else {
            if(getProfessionalIdSelected() == 5 && day_name.format('dddd') != 'viernes') {
                $('.fc-enable_all-button').hide();
                $('.fc-enable_one-button').hide();
            } else {
                $('.fc-enable_all-button').show();
                $('.fc-enable_one-button').show();
            }
        }
    }
    // @END
    var viewRender = function(view, element) {
        if(view.name=="agendaWeek" || view.name=="agendaDay"){
            $('.fc-print_day-button').hide();
        }else{
            $('.fc-print_day-button').show();
        }
        
        // @CARDIOINFANTIL
        updateButtons();
        // @END        
    }

    $('select#professional').on('change',function(){
        updateButtons();
    });
    $('#calendar').fullCalendar({
        // put your options and callbacks here
        locale: 'es',
        defaultView: 'agendaDay',
        slotDuration: '00:10:00',
        timeFormat: 'H:mm', // uppercase H for 24-hour clock
        minTime: '11:00:00',
        maxTime: '22:00:00',
        allDaySlot: false,
        buttonText: 
            {
                listDay: 'Lista de día',
                listWeek: 'Lista de semana',
            },
        header :
            {
                left: 'prev,next today enable_all,enable_one',
                center: 'title print_day',
                right: 'agendaDay,listDay'
            },
        customButtons: {
            enable_all: {
                text: 'Crear Todos',
                click: function() {
                    habilitar($('#calendar').fullCalendar('getView'));
                }
            },
            disable_all: {
                text: 'Eliminar Todos',
                click: function() {
                    alert(); 
                }
            },
            enable_one: {
                text: 'Crear uno',
                click: function() {
                    createUniqueAppointment();
                }
            },
            print_day: {
                text: 'Imprimir',
                click: function() {
                    printAgenda($('#calendar').fullCalendar('getView'));
                }
            }
        },
        viewRender: function(view, element) {
            viewRender(view, element);
        },
        eventRender: function(event, element) {
            element.find('.fc-content').prepend( "<i  class='fa fa-close pull-left text-danger' id='delete'></i>" );
        },

        eventClick: function(calEvent, jsEvent, view) {
            if (jsEvent.target.id === 'delete') {
                if(confirm('¿Esta seguro que desea eliminar este turno?')){
                    deleteAppointment(calEvent);
                }
            } else {
                showEditAppointmentModal(calEvent, jsEvent, view);
            }
        },
        dayClick: function(date, jsEvent, view) {
                var day = date.day(); // number 0-6 with Sunday as 0 and Saturday as 6
                alert(day);
        },
        eventSources: [fcSources.availables, fcSources.taken, fcSources.waiting, fcSources.ended]
    });
    /**************************************************************************
     * Printer Function
     **************************************************************************/
     var getPdfHeader = function() {
        
        var pdfHeader = '<h2>Profesional: '+ getProfessionalNameSelected() +'</h2>'
                       +'<h3>Fecha: '+ getDateSelected() +'</h2>'
                       +'<h4>Turnos otorgados: ' + getNumberOfAppointments() + ' </h4>';

        return pdfHeader;        
     }

     var printAgenda = function(view) {
        //console.log(getNumberOfAppointments());
        $(".fc-list-table").printThis({
            debug: false,               // show the iframe for debugging
            importCSS: true,            // import page CSS
            importStyle: false,         // import style tags
            printContainer: true,       // grab outer container as well as the contents of the selector
            //loadCSS: "path/to/my.css",  // path to additional css file - use an array [] for multiple
            removeInline: false,        // remove all inline styles from print elements
            printDelay: 333,            // variable print delay; depending on complexity a higher value may be necessary
            header: getPdfHeader(), // prefix to html
            footer:  $('.hidden-print-header-content'),               // postfix to html
            base: false ,               // preserve the BASE tag, or accept a string for the URL
            formValues: true,           // preserve input/form values
            canvas: false,              // copy canvas elements (experimental)
            removeScripts: false        // remove script tags from print content
        });
     }

    /**************************************************************************
     * New appointments modal wrapper
     **************************************************************************/
     var habilitar = function(view) {
        
        var professional = $('#professional option:selected').text();
        
        $('#professionalName').text(professional);
        if(view.name=="agendaDay" || view.name == 'listDay'){
            $('#modalForm').modal('show');
        }else{
            showNewWeekAppointmentsModal();
        }
    }

    $('#professional').on('change', function(){
        $('#calendar').fullCalendar('refetchEvents');
    });

    /**************************************************************************
     * New Day Appointment Modal
     **************************************************************************/    
    $('#newAppointmentsModalForm').submit(function(event){  
        
        event.preventDefault();

        $('input[name="professional_id"]').val(getProfessionalIdSelected());
        
        $('input[name="date_from"]').val(getDateSelected());

        $('input[name="date_until"]').val(getDateSelected());
        
        $.ajax({
            url: '/api/calendar/bulk',
            data: $('#newAppointmentsModalForm').serialize(),
            type: "POST",
            success: function () {
                $('#calendar').fullCalendar('refetchEvents');
                $('#modalForm').modal('hide');
                updateFlashMessage('success','Los turnos se dieron de alta correctamente');
            },
            error: function() {
                $('#modalForm').modal('hide');
                updateFlashMessage('danger','No se dió de alta ningún turno. Por favor verifique que el profesional trabaje en el día indicado. De ser así, inténtelo de nuevo más tarde.');  
            }
        });
    
    });

    /**************************************************************************
     * New Week Appointment Modal
     **************************************************************************/
     var showNewWeekAppointmentsModal = function() {
        $('input[name="date_from"]').val(getStartWeekDateSelected());

        $('input[name="date_until"]').val(getEndWeekDateSelected());

        $('#newWeekAppointmentsModal').modal('show');
        
     }
    $('#newWeekAppointmentsModalForm').submit(function(event){  
        
        event.preventDefault();

        $('input[name="professional_id"]').val(getProfessionalIdSelected());
        

        $.ajax({
            url: '/api/calendar/bulk',
            data: $('#newWeekAppointmentsModalForm').serialize(),
            type: "POST",
            success: function () {
                $('#calendar').fullCalendar('refetchEvents');
                $('#newWeekAppointmentsModal').modal('hide');
                updateFlashMessage('success','Los turnos se dieron de alta correctamente');
            },
            error: function() {
                $('#newWeekAppointmentsModal').modal('hide');
                updateFlashMessage('danger','No se dió de alta ningún turno. Por favor verifique que el profesional trabaje en el día indicado. De ser así, inténtelo de nuevo más tarde.');  
            }
        });
    
    });

    /**************************************************************************
     * Edit Appointment Modal
     **************************************************************************/
    
    $('#btn-liberar').on('click', function(){
        $('#patient_id').val(null);
        $('#insurance_id').val(null);
        $('#status').val(0);
        $('#medical_study_id').val(null);
        $('#comment').val('');
        $('#money').val('');
        $('#coupons').val('');
    });

    $('#editAppointmentModalForm #patient_id').on('change', function(){

        getPatientInformation($('#patient_id').val());

    });

    var updatePatientInformation = function(data) {
        $('#insurance').val(data.insurance);
        $('#status').val(1);
    }

    var showEditAppointmentModal = function(calEvent, jsEvent, view) {

        var professional = $('#professional option:selected').text();

        $('#modalEditAppointment input[name="professional_id"]').val(getProfessionalIdSelected());
        
        $('#modalEditAppointment #editModalProfessionalName').text(professional);
        $('#modalEditAppointment #invisible_id').val(calEvent.id);
        $('#modalEditAppointment #editModalDate').text(calEvent.date);
        $('#modalEditAppointment #editModalTime').text(calEvent.time);
        $('#modalEditAppointment #patient_id').val(calEvent.pati_id);
        $('#modalEditAppointment #status').val(calEvent.status_id);
        $('#modalEditAppointment #medical_study_id').val(calEvent.medical_study_id);
        $('#modalEditAppointment #insurance_id').val(calEvent.insurance_id);
        $('#modalEditAppointment #comment').val(calEvent.comment);
        $('#modalEditAppointment #money').val(calEvent.money);
        $('#modalEditAppointment #coupons').val(calEvent.coupons);
        
        resetSearchPatientPanel();

        $('#modalEditAppointment').modal('show');
    }

    $('#modalEditAppointment').submit(function(event){
        
        event.preventDefault();
        
        submitEditModal();
    });

    /**************************************************************************
     * Search Patient By Dni
     **************************************************************************/
    var patientFound = false;
    var patient_id = null;

    var resetFieldsSearchPatient = function(){
        $('.patient-surname').val('');
        $('.patient-name').val('');
        $('.patient-address').val('');
        $('.patient-primary-phone').val('');
        $('.patient-secondary-phone').val('');
        $('.patient-insurance-id').val('');
        $('.patient-plan').val('');
        $('.patient-affiliate-number').val('');
        $('.patient-professional-id').val('');
    }

    var setFieldsSearchPatient = function(data){
        console.log(data);
        $('.patient-surname').val(data.surname);
        $('.patient-name').val(data.name);
        $('.patient-address').val(data.address);
        $('.patient-primary-phone').val(data.primary_phone);
        $('.patient-secondary-phone').val(data.secondary_phone);
        $('.patient-insurance-id').val(data.insurance_id);
        $('.patient-plan').val(data.plan);
        $('.patient-affiliate-number').val(data.affiliate_number);
        $('.patient-professional-id').val(data.professional_id);
    }

    var resetSearchPatientPanel = function(){
        //Hide error messages and new patient panel
        //$('.searchpatient-panel').hide();
        $('.error-msg').hide();
        $('.success-msg').hide();

        $('.patient-dni').val('');
        resetFieldsSearchPatient();
        
        $('.searchpatient-panel').hide();

    }

    var getPatientInformationByDni = function(dni, panel) {
        $.ajax({
            url: '/api/patients/dni/'+dni,
            type: "GET",
            success: function (data) {
                updateSearchPatientInformation(data, panel);
            },
            error: function (data) {
                if (data.status = "Not Found") {
                    updatePatientNotFound(panel);
                };
            }
        });  
     }

    var storePatient = function(form) {
        var data = $("#newPatientForm").serialize(); 
        console.log(data);       
        $.ajax({
            url: '/api/patients',
            data: data,
            type: "POST",
            success: function (data, textStatus, xhr) {
                console.log(xhr.status);
                patient_id = data.id;
                addPatientToSelect(data);
                patientFound = true;
                selectPatient(form);
                form.find('.patient-success-msg').show();
                form.find('.patient-error-msg').hide();
                // changeStatusIfNotSelected(form);

            },
            error: function(textStatus, xhr) {
                form.find('.patient-success-msg').hide();
                form.find('.patient-error-msg').show();
                console.log(xhr.status);
            }
        });
     }

    var addPatientToSelect = function(data) {
        $('select[name="patient_id"]').append($('<option>', {
            value: data.id,
            text: data.name + ' ' + data.surname
        }));
    }

    var updateSearchPatientInformation = function(data, panel) {
        //console.log(data);
        panel.find('.search-error-msg').hide();
        panel.find('.search-success-msg').show();

        setFieldsSearchPatient(data);
        patientFound = true;
        patient_id = data.id
    }

    var updatePatientNotFound = function(panel) {
        panel.find('.search-success-msg').hide();
        panel.find('.search-error-msg').show();
        
        resetFieldsSearchPatient();

        patientFound = false;
    }

    $('.search-patient').on('click', function(){
        clearSearchPatientForm();
        $('.searchpatient-panel').show('slow');
    });

    var clearSearchPatientForm = function() {
        patientFound = false;
        $('.success-msg').hide();
        $('.error-msg').hide();

        $('.patient-dni').val('');
        resetFieldsSearchPatient();

    };

    $('.search-dni').on('click', function(){
        var panel = $(this).closest('.panel');
        getPatientInformationByDni($(this).parent('.form-group').find('.patient-dni').val(), panel);
    });

    $('.search-cancel').on('click', function(){
        $('.searchpatient-panel').hide('slow');
    });

    var selectPatient = function(form) {
        form.find('select[name="patient_id"]').val(patient_id);
    };

    var changeStatusIfNotSelected = function(form){
        var select = form.find('select[name="status"]');
        if(select.find('option:selected').val() == 0) {
            select.val(1);
        }
    }
    $('.search-confirm').on('click', function(){
        var form = $(this).closest('.form');

        if(patientFound) {
            selectPatient(form);
            $(this).parent('.form-group').find('.success-msg').show();
            $(this).parent('.form-group').find('.error-msg').hide();
            changeStatusIfNotSelected(form);
            $('.searchpatient-panel').hide('slow');
        } else {
            $('#newPatientForm input[name="dni"]').val(form.find('.patient-dni').val());
            $('#newPatientForm input[name="name"]').val(form.find('.patient-name').val());
            $('#newPatientForm input[name="surname"]').val(form.find('.patient-surname').val());
            $('#newPatientForm input[name="address"]').val(form.find('.patient-address').val());
            $('#newPatientForm input[name="primary_phone"]').val(form.find('.patient-primary-phone').val());
            $('#newPatientForm input[name="secondary_phone"]').val(form.find('.patient-secondary-phone').val());
            $('#newPatientForm input[name="affiliate_number"]').val(form.find('.patient-affiliate-number').val());
            $('#newPatientForm input[name="insurance_id"]').val(form.find('.patient-insurance-id').val());
            $('#newPatientForm input[name="professional_id"]').val(form.find('.patient-professional-id').val());
            $('#newPatientForm input[name="plan"]').val(form.find('.patient-plan').val());
            
            storePatient(form);
            $('.searchpatient-panel').hide('slow');
        }

    });

    /**************************************************************************
     * New Unique Appointment Modal
     **************************************************************************/    
     var createUniqueAppointment = function() {
        var professional = $('#professional option:selected').text();
        
        $('.new-appointment-error-msg').hide();
        
        $('#uniqueAppointmentModal #professionalName').text(professional);
        //reset fields
        $('#uniqueAppointmentModal #patient_id').val(null);
        $('#uniqueAppointmentModal #status').val(1);
        $('#uniqueAppointmentModal #insurance_id option:contains("Seleccionar")').prop('selected', true);
        $('#uniqueAppointmentModal #medical_study_id option:contains("Seleccionar")').prop('selected', true);
        $('#uniqueAppointmentModal #money').val('');
        $('#uniqueAppointmentModal #coupons').val('');
        $('#uniqueAppointmentModal #timepicker').val('');
        $('#uniqueAppointmentModal #date').val('');
        //set professional_id
        $('#uniqueAppointmentModal input[name="professional_id"]').val(getProfessionalIdSelected());

        resetSearchPatientPanel();

        $('#uniqueAppointmentModal').modal('show');
    };


    $('#uniqueAppointmentModal').submit(function(event){  
        
        event.preventDefault();
        
        if(validateCreateUniqueAppointment()) {

            submitCreateUniqueAppointment();
        }

    });

    var validateCreateUniqueAppointment = function(){
        console.log('validation');
        
        $('.new-appointment-error-msg').hide();

        var errors = false;
        //fecha seleccionada
        if($('#uniqueAppointmentModal #date').val() == ''){
            errors = true;
            $('#new-appointment-date-error').show();
        }
        //hora seleccionada
        if($('#uniqueAppointmentModal #timepicker').val() == ''){
            errors = true;
            $('#new-appointment-timepicker-error').show();
        }
        //paciente seleccionado
        /*
        if($( "#uniqueAppointmentModal #patient_id option:selected" ).text() == 'Seleccionar'){
            errors = true;
            $('#new-appointment-patient_id-error').show();
        }      
        */
        return !errors;
    }
    /**************************************************************************
     * Ajax Calls
     **************************************************************************/

    var submitCreateUniqueAppointment = function() {
        if($('#uniqueAppointmentModal #insurance_id option:selected').text() == 'Seleccionar'){
            $('#uniqueAppointmentModal #insurance_id').val(null);
        }
        var data = $("#uniqueAppointmentModalForm").serialize();

        console.log(data);
        
        $.ajax({
            url: '/api/appointments',
            data: data,
            type: "POST",
            success: function () {
                console.log('success');
                $('#calendar').fullCalendar('refetchEvents');
                $('#uniqueAppointmentModal').modal('hide');
                updateFlashMessage('success','El turno se creó correctamente');
            },
            error: function() {
                $('#uniqueAppointmentModal').modal('hide');
                updateFlashMessage('danger','El turno no se pudo crear. Por favor inténtelo más tarde.');  
            }
        });
    }

     var getPatientInformation = function(patient_id){
        $.ajax({
            url: '/api/patients/'+patient_id,
            type: "GET",
            success: function (data) {
                console.log('success');
                updatePatientInformation(data);
            }
        });
     }

    var deleteAppointment = function(calEvent){
        $.ajax({
            url: '/api/appointments/'+calEvent.id,
            type: "DELETE",
            success: function () {
                $('#calendar').fullCalendar('removeEvents', calEvent.id);
                updateFlashMessage('success','El turno se borró correctamente');
            },
            error: function() {
                updateFlashMessage('danger','El turno no se pudo borrar. Por favor intentélo más tarde.');  
            }
        });
    }

    var submitEditModal = function(){
        
        var data = $("#editAppointmentModalForm").serialize();
        var appointment_id = $('#invisible_id').val();
        
        console.log(data);

        $.ajax({
            url: '/api/appointments/'+appointment_id,
            data: data,
            type: "PUT",
            success: function () {
                console.log('success');
                $('#calendar').fullCalendar('refetchEvents');
                $('#modalEditAppointment').modal('hide');
                updateFlashMessage('success','El turno se actualizó correctamente');
            },
            error: function() {
                $('#modalEditAppointment').modal('hide');
                updateFlashMessage('danger','El turno no se pudo actualizar correctamente. Por favor inténtelo más tarde.');  
            }

        });
    }
  
    /**************************************************************************
     * Flash messages
     **************************************************************************/

     var updateFlashMessage = function(type, msg) {
        
        var div = $('.flash-message');
        
        div.removeClass();
        div.addClass('flash-message alert alert-'+type);
        div.text(msg);

     }

     /**************************************************************************
     * Date and Time pickers
     **************************************************************************/
     $('#timepicker').datetimepicker({   
        datepicker:false,
        format:'H:i',
        step: 10,
        minTime: '11:00',
        maxTime: '21:01',
        onGenerate:function( ct ){
            $(this).addClass('hidden-disabled')
        }
        }
    );

    $('.datepicker').datetimepicker({   
        timepicker: false,
        format: 'Y-m-d',
        minDate: 0,
        lang: 'es'        
        }
    );
});