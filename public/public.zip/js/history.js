$(document).ready(function() {

    var editComment = function(elem) {

    }

    /***********************************************************************
     * Comment buttons
     ***********************************************************************/

     $('.btn-edit').on('click', function(event) { 
        $(this).siblings('.btn-save').show();
        $(this).siblings('.btn-cancel').show();
        $(this).siblings('.btn-delete').hide();
        $(this).hide();

     });

     $('.btn-save').on('click', function(event) { 
        $(this).siblings('.btn-edit').show();
        $(this).siblings('.btn-delete').show();
        $(this).siblings('.btn-cancel').hide();
        $(this).hide();
     });

     $('.btn-cancel').on('click', function(event) { 
        $(this).siblings('.btn-delete').show();
        $(this).siblings('.btn-edit').show();
        $(this).siblings('.btn-save').hide();
        $(this).hide();
     });

     $('.btn-delete').on('click', function(event) { 
        alert('comentario borrado');
     });
});